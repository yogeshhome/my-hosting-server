#!/bin/bash

# Exit if any command fails
set -e

# Create workflow directory
mkdir -p .github/workflows

# Generate CI workflow file
cat > .github/workflows/ci.yml <<'EOF'
name: CI Pipeline

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      # 1. Checkout code
      - name: Checkout Repository
        uses: actions/checkout@v3

      # 2. Setup Node.js (adjust version if needed)
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'

      # 3. Install dependencies
      - name: Install Dependencies
        run: npm install

      # 4. Run tests
      - name: Run Tests
        run: npm test

      # 5. Build Docker image
      - name: Build Docker Image
        run: docker build -t my-app:${{ github.sha }} .

      # 6. Push Docker image (optional: requires registry creds)
      - name: Log in to DockerHub
        uses: docker/login-action@v2
        with:
          username: ${{ secrets.DOCKER_USERNAME }}
          password: ${{ secrets.DOCKER_PASSWORD }}

      - name: Push Docker Image
        run: docker push my-app:${{ github.sha }}
EOF

echo "✅ GitHub Actions CI workflow created at .github/workflows/ci.yml"
